# Arquivo: server.zip/socorroserver/node.gd

extends Node
class_name ServerNode

var server = UDPServer.new()

# Mapeia cada peer para sua posição e nome
# Chave: "ip:port" -> Valor: Dictionary com "name", "position", "ip", "port"
var players = {}  

# Constantes para os tipos de mensagens
const MSG_REGISTER = "REGISTER"
const MSG_POS = "POS"
const MSG_PLAYER_POSITIONS = "PLAYER_POSITIONS"

func _ready():
	server.listen(4242)
	print("Servidor escutando na porta 4242")

func _process(delta):
	server.poll()

	if server.is_connection_available():
		var peer = server.take_connection()
		var packet_str = peer.get_packet().get_string_from_utf8()
		
		var ip = peer.get_packet_ip()
		var port = peer.get_packet_port()
		var id = "%s:%s" % [ip, port]

		var parts = packet_str.split(":")
		var message_type = parts[0]
		
		match message_type:
			# Comando para registrar um novo jogador
			MSG_REGISTER:
				if parts.size() >= 2:
					var player_name = parts[1]
					if not players.has(id):
						players[id] = {
							"name": player_name,
							"position": Vector2.ZERO, # Posição inicial
							"ip": ip,
							"port": port
						}
						print("Novo jogador registrado: '%s' com ID %s" % [player_name, id])
					else:
						# Atualiza o nome se o jogador já existir
						players[id]["name"] = player_name
						print("Nome do jogador %s atualizado para '%s'" % [id, player_name])
				else:
					print("Mensagem de registro inválida de %s" % id)
			
			# Comando para atualizar a posição do jogador
			MSG_POS:
				if parts.size() == 3 and players.has(id):
					var x = parts[1].to_float()
					var y = parts[2].to_float()
					players[id]["position"] = Vector2(x, y)
					print("Jogador '%s' (%s) está em (%.2f, %.2f)" % [players[id]["name"], id, x, y])
				elif not players.has(id):
					print("Jogador com ID %s não registrado. Posição ignorada." % id)
				else:
					print("Mensagem de posição inválida de %s" % id)
			
			_:
				print("Mensagem desconhecida de %s: %s" % [id, packet_str])
		
		# Envia as posições de todos os jogadores (evento) de volta para este peer
		var message_parts = []
		for other_id in players:
			var pos = players[other_id]["position"]
			var name = players[other_id]["name"]
			# Agora inclui o nome na resposta
			message_parts.append("%s:%s:%.1f:%.1f" % [other_id, name, pos.x, pos.y])
		
		var response = "%s:%s" % [MSG_PLAYER_POSITIONS, ";".join(message_parts)]
		peer.put_packet(response.to_utf8_buffer())
