extends Node

var udp = PacketPeerUDP.new()

@export var remote_player_scene: PackedScene  # Cena do jogador remoto 

# Dicionário
# Chave: "ip:port" = Valor: Node do jogador
var remote_players = {}

func _ready():
	udp.connect_to_host("127.0.0.1", 4242) #ip e porta
	
	# O cliente se registra com um nome ao iniciar.
	var register_message = "REGISTER:jogador_local2"
	udp.put_packet(register_message.to_utf8_buffer())
	print("Enviando mensagem de registro: ", register_message)


func _process(delta):
	var player = get_node("../pleyer")  #Pegando cena pleyer
	if player == null:
		print("Jogador local não encontrado!")
		return

	# Envia posição atual do jogador local
	var position = player.global_position
	var message = "POS:%f:%f" % [position.x, position.y]
	udp.put_packet(message.to_utf8_buffer()) #Manda posicao pro servidor

	# Verifica e processa a resposta do servidor de forma assíncrona.
	while udp.get_available_packet_count() > 0:
		var data = udp.get_packet().get_string_from_utf8()
		
		# Print toda mensagem recebida
		print("Mensagem recebida do servidor: ", data)
		
		# Divide a mensagem para verificar o tipo
		var parts = data.split(":")
		var message_type = parts[0]
		
		if message_type == "PLAYER_POSITIONS":
			# A mensagem contém as posições dos jogadores
			var player_data = parts[1].split(";")
			
			# Cria uma lista dos IDs dos jogadores que ainda estão no servidor
			var active_players = []
			
			for player_info_str in player_data:
				var info_parts = player_info_str.split(":")
				#Informações do jogador
				if info_parts.size() >= 4:
					var player_id = info_parts[0]
					var player_name = info_parts[1]
					var x = info_parts[2].to_float()
					var y = info_parts[3].to_float()
					var new_position = Vector2(x, y)
					
					active_players.append(player_id)
					
					# Se não for o jogador local, atualiza o jogador remoto
					if player_id != "%s:%s" % [udp.get_packet_ip(), udp.get_packet_port()]:
						if not remote_players.has(player_id):
							# Se o jogador remoto ainda não existe, cria um novo
							var new_remote_player = remote_player_scene.instantiate()
							new_remote_player.name = player_name
							add_child(new_remote_player)
							remote_players[player_id] = new_remote_player
							print("Novo jogador remoto '%s' (%s) criado." % [player_name, player_id])
						
						# Atualiza a posição do jogador remoto
						var remote_player = remote_players[player_id]
						remote_player.global_position = new_position
						
			# Remove jogadores remotos que não estão mais na lista do servidor
			var players_to_remove = []
			for id in remote_players.keys():
				if not id in active_players:
					players_to_remove.append(id)
			
			for id in players_to_remove:
				var player_node = remote_players.get(id)
				if player_node:
					print("Removendo jogador remoto '%s' (%s)." % [player_node.name, id])
					player_node.queue_free()
					remote_players.erase(id)
		
		else:
			print("Mensagem desconhecida do servidor: ", data)
