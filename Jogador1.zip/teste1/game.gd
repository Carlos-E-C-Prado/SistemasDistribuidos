extends Node2D

var peer =ENetMultiplayerPeer.new()
@export var player_scen :PackedScene

var server := TCPServer.new()
var clients: Array[StreamPeerTCP] = []

const PORT = 1027


		
func _on_host_pressed() -> void:
	#var err = server.listen(PORT)
	#peer.create_server(1027)
	pass

func _on_join_pressed() -> void:
	pass # Replace with function body.
